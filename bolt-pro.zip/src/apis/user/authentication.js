// authService.js
import { baseUrl, token } from "../../utils";


async function loginUser(email, password, deviceType = 'web') {
  console.log('email ', email, 'password: ', password, 'deviceType:', deviceType)
  const res = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json', // ✅ Tells the server you're sending JSON
    },
    body: JSON.stringify({ email, password, deviceType }),
  });
  const data = await res.json();
  console.log('data ', data)
  return data;
}

async function userProfileUpdate(newData) {
  console.log('email ', email, 'password: ', password)
  const res = await fetch(`${baseUrl}/user/updateprofile`, {
    method: 'POST',
    body: JSON.stringify(newData),
  });
  const data = await res.json();
  console.log('usr new data ', data)
  return data;
}




export { loginUser, userProfileUpdate }
