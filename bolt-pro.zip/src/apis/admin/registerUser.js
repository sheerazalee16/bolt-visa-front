import { baseUrl, token } from "../../utils";

async function registerUser(userData) {
  console.log('userData .... ', userData)
  const res = await fetch(`${baseUrl}/admin/register`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(userData),
  });
  const data = await res.json();
  console.log('register data', data);
  
  return data;
}

export {registerUser}
