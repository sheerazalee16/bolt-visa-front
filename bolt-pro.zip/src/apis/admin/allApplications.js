import { baseUrl } from "../../utils";


async function fetchAllApplications() {
    try {
        const token = localStorage.getItem('bolt_visa_token');
        const res = await fetch(`${baseUrl}/application?page=1&limit=10`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
                // You can add auth headers here if needed
                // 'Authorization': `Bearer ${token}`
            },
        });

        const data = await res.json();
        if (!res.ok) {
            return { success: false, error: data.message || 'Failed to fetch users' };
        }

        return { success: true, data };
    } catch (error) {
        return { success: false, error: 'Network error' };
    }
}

export { fetchAllApplications };
