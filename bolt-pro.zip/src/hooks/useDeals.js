import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth.jsx';
import { fetchAllApplications } from '../apis/admin/allApplications';

export const useDeals = (isAdminView = false) => {
  const { user } = useAuth();
  const [deals, setDeals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [applications, setApplications] = useState({})

  const loadDeals = useCallback(async () => {
    setLoading(true);
    let data = {};
    let allDeals = []
    try {
      data = await fetchAllApplications()
      console.log('API response:', data);
      
      // Try to get applications from API response
      allDeals = data?.data?.data?.applications || data?.data?.applications || data?.applications || [];
      
      console.log('data ...  ', allDeals)
      console.log('allDeals ', allDeals)
      
      // If API returns no data, fallback to localStorage
      if (!allDeals || allDeals.length === 0) {
        console.log('No data from API, using localStorage fallback');
        allDeals = JSON.parse(localStorage.getItem('bolt_visa_deals') || '[]');
      }
      
      if (isAdminView) {
        setDeals(allDeals || []);
      } else if (user) {
        setDeals((allDeals || []).filter(deal => deal.userId === user.id));
      } else {
        setDeals([]);
      }
      setLoading(false);
    }
    catch (err) {
      console.log('applications error ', err)
      // Fallback to localStorage on error
      const fallbackDeals = JSON.parse(localStorage.getItem('bolt_visa_deals') || '[]');
      if (isAdminView) {
        setDeals(fallbackDeals);
      } else if (user) {
        setDeals(fallbackDeals.filter(deal => deal.userId === user.id));
      } else {
        setDeals([]);
      }
      setLoading(false);
    }
  }, [user, isAdminView]);

  useEffect(() => {
    loadDeals();
  }, [loadDeals]);

  const generateCaseId = (applyFor) => {
    if (!applyFor) return `UNDEF${Date.now().toString().slice(-5)}`;
    const countryCode = applyFor.toUpperCase().substring(0, 3);
    const existingCases = JSON.parse(localStorage.getItem('bolt_visa_deals') || '[]');
    const countryDeals = existingCases.filter(deal => deal.caseId?.startsWith(countryCode));
    const nextNumber = countryDeals.length + 1;
    return `${countryCode}${nextNumber.toString().padStart(3, '0')}`;
  };

  const addDeal = (dealData) => {
    if (!user) return { success: false, error: "User not authenticated" };

    const allDeals = JSON.parse(localStorage.getItem('bolt_visa_deals') || '[]');
    const caseId = generateCaseId(dealData.applyFor);

    const newDeal = {
      id: Date.now().toString(),
      ...dealData,
      caseId,
      userId: user.id,
      userName: user.name,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    allDeals.push(newDeal);
    localStorage.setItem('bolt_visa_deals', JSON.stringify(allDeals));
    loadDeals();
    return { success: true, caseId };
  };

  const updateUserEarningsOnApproval = (dealUserId, dealType) => {
    const users = JSON.parse(localStorage.getItem('bolt_visa_users') || '[]');
    const userIndex = users.findIndex(u => u.id === dealUserId);

    if (userIndex !== -1) {
      const reward = dealType === 'main' ? 2000 : 1000;
      users[userIndex].totalEarnings = (users[userIndex].totalEarnings || 0) + reward;

      if (dealType === 'main') {
        users[userIndex].mainDeals = (users[userIndex].mainDeals || 0) + 1;
      } else {
        users[userIndex].referenceDeals = (users[userIndex].referenceDeals || 0) + 1;
      }

      localStorage.setItem('bolt_visa_users', JSON.stringify(users));

      if (user && user.id === dealUserId) {
        const currentUserSession = JSON.parse(localStorage.getItem('bolt_visa_user'));
        if (currentUserSession) {
          currentUserSession.totalEarnings = users[userIndex].totalEarnings;
          currentUserSession.mainDeals = users[userIndex].mainDeals;
          currentUserSession.referenceDeals = users[userIndex].referenceDeals;
          localStorage.setItem('bolt_visa_user', JSON.stringify(currentUserSession));
        }
      }
    }
  };

  const updateDeal = (id, updates) => {
    const allDeals = JSON.parse(localStorage.getItem('bolt_visa_deals') || '[]');
    const index = allDeals.findIndex(deal => deal.id === id);

    if (index !== -1) {
      allDeals[index] = { ...allDeals[index], ...updates };
      localStorage.setItem('bolt_visa_deals', JSON.stringify(allDeals));
      loadDeals();
      return { success: true };
    }
    return { success: false, error: 'Deal not found' };
  };

  const deleteDeal = (id) => {
    const allDeals = JSON.parse(localStorage.getItem('bolt_visa_deals') || '[]');
    const filteredDeals = allDeals.filter(deal => deal.id !== id);
    localStorage.setItem('bolt_visa_deals', JSON.stringify(filteredDeals));
    loadDeals();
    return { success: true };
  };

  const approveDeal = (id) => {
    const allDeals = JSON.parse(localStorage.getItem('bolt_visa_deals') || '[]');
    const dealIndex = allDeals.findIndex(d => d.id === id);
    if (dealIndex !== -1) {
      const dealToApprove = allDeals[dealIndex];
      if (dealToApprove.status !== 'approved') {
        updateUserEarningsOnApproval(dealToApprove.userId, dealToApprove.dealType);
      }
      return updateDeal(id, { status: 'approved', approvedAt: new Date().toISOString() });
    }
    return { success: false, error: "Deal not found for approval." };
  };

  const rejectDeal = (id, reason) => {
    return updateDeal(id, { status: 'rejected', rejectedAt: new Date().toISOString(), rejectionReason: reason });
  };

  return {
    deals,
    loading,
    addDeal,
    updateDeal,
    deleteDeal,
    approveDeal,
    rejectDeal,
    refreshDeals: loadDeals
  };
};