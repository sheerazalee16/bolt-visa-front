import React, { useState, useEffect, useMemo } from 'react';
import { useDeals } from '@/hooks/useDeals';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { countries } from '@/data/countries';
import { Plus, FileText, User, MapPin, CreditCard, Wallet, Search, Minus, X, Maximize2 } from 'lucide-react';

const DealForm = ({ isOpen, onClose, deal = null }) => {
  const { addDeal, updateDeal } = useDeals();
  const [formData, setFormData] = useState({
    dealType: 'main',
    applyFrom: '',
    userDetails: [{
      firstName: '',
      lastName: '',
      passportNumber: '',
      nationality: '',
      phoneNumber: '',
    }],
    applyFor: '',
    totalAmount: '',
    paidAmount: '',
    remainingPayment: '',
    currency: 'PKR',
    paymentMethod: 'online',
    installments: {
      first: { amount: '', paid: false, paymentMethod: 'online' },
      second: { amount: '', paid: false, paymentMethod: 'online' },
      third: { amount: '', paid: false, paymentMethod: 'online' },
      fourth: { amount: '', paid: false, paymentMethod: 'online' }
    },
    bonusType: '',
    // promoCode: '',
    status: 'pending'
  });


  const abc = {
    "dealType": "Main Deal",
    "applyFrom": "Pakistan",
    "destination": "Germany",
    "type": "single", //single, multiple
    "clientInfo": [
      {
        "firstName": "Client 1",
        "lastName": "Test",
        "passportNumber": "111",
        "phoneNumber": "00001",
        "nationality": "Pakistani"
      }
      // ,
      // {
      //     "firstName": "Client 2",
      //     "lastName": "Test",
      //     "passportNumber": "222",
      //     "phoneNumber": "00002",
      //     "nationality": "Pakistani"
      // }
    ],
    "payment": {
      "currency": "PKR", // PKR, AED, USD
      "totalAmount": 1000,
      "paidAmount": 500,
      // "remainingAmount": 50,
      "overallPaymentMethod": "Online Transfer", //Online Transfer, Payment Link, Cash Payment, Money Exchange, Cryptocurrency
      "installments": [
        {
          "amount": 10,
          "paymentMethod": "Online Transfer",
          "isPaid": true,
          "paidAt": "2025-10-25"
        }
      ]
    }
  }



  // useEffect(() => {
  //   if (deal) {
  //     setFormData(prev => ({
  //       ...prev,
  //       ...deal,
  //       totalAmount: deal.totalAmount || '',
  //       paidAmount: deal.paidAmount || '',
  //       remainingPayment: deal.remainingPayment || '',
  //       installments: deal.installments || {
  //         first: { amount: '', paid: false, paymentMethod: 'online' },
  //         second: { amount: '', paid: false, paymentMethod: 'online' },
  //         third: { amount: '', paid: false, paymentMethod: 'online' },
  //         fourth: { amount: '', paid: false, paymentMethod: 'online' }
  //       }
  //     }));
  //   } 

  //   else {
  //     setFormData({
  //       firstName: '',
  //       lastName: '',
  //       passportNumber: '',
  //       nationality: '',
  //       phoneNumber: '',
  //       dealType: 'main',
  //       applyFrom: '',
  //       applyFor: '',
  //       totalAmount: '',
  //       paidAmount: '',
  //       remainingPayment: '',
  //       currency: 'PKR',
  //       paymentMethod: 'online',
  //       installments: {
  //         first: { amount: '', paid: false, paymentMethod: 'online' },
  //         second: { amount: '', paid: false, paymentMethod: 'online' },
  //         third: { amount: '', paid: false, paymentMethod: 'online' },
  //         fourth: { amount: '', paid: false, paymentMethod: 'online' }
  //       },
  //       bonusType: '',
  //       promoCode: '',
  //       status: 'pending'
  //     });
  //   }
  // }, [deal, isOpen]);

  // useEffect(() => {
  //   const totalPaid = Object.values(formData.installments).reduce((sum, inst) => {
  //     return inst.paid && inst.amount ? sum + parseFloat(inst.amount) : sum;
  //   }, 0);
  //   const remaining = parseFloat(formData.totalAmount || 0) - totalPaid;
  //   setFormData(prev => ({
  //     ...prev,
  //     paidAmount: totalPaid > 0 ? totalPaid.toString() : '',
  //     remainingPayment: remaining > 0 || parseFloat(formData.totalAmount || 0) > 0 ? remaining.toString() : ''
  //   }));
  // }, [formData.installments, formData.totalAmount]);


  const dealTypes = [
    { value: 'main', label: 'Main Deal', reward: 2000 },
    { value: 'reference', label: 'Reference Deal', reward: 1000 },
    { value: 'family', label: 'Family Deal', reward: 1000 }
  ];

  const currencies = [
    { value: 'PKR', label: 'Pakistani Rupee (PKR)', symbol: '₨' },
    { value: 'AED', label: 'UAE Dirham (AED)', symbol: 'د.إ' },
    { value: 'USD', label: 'US Dollar (USD)', symbol: '$' },
    { value: 'Crypto', label: 'Crypto Currency', symbol: 'C' }
  ];

  const paymentMethods = [
    { value: 'online', label: 'Online Transfer' },
    { value: 'cash', label: 'Cash Payment' },
    { value: 'payment_link', label: 'Payment Link' },
    { value: 'money_exchange', label: 'Money Exchange' },
    { value: 'cryptocurrency', label: 'Cryptocurrency' }
  ];

  const bonusTypes = [
    'Performance Bonus',
    'Monthly Target Bonus',
    'Special Achievement',
    'Team Bonus',
    'Holiday Bonus'
  ];

  const handleSubmit = (e) => {
    e.preventDefault();

    let totalPaidFromInstallments = 0;
    Object.values(formData.installments).forEach(inst => {
      if (inst.paid && inst.amount) {
        totalPaidFromInstallments += parseFloat(inst.amount);
      }
    });

    const remaining = parseFloat(formData.totalAmount || 0) - totalPaidFromInstallments;
    const finalData = {
      ...formData,
      paidAmount: totalPaidFromInstallments > 0 ? totalPaidFromInstallments.toString() : '',
      remainingPayment: remaining > 0 || parseFloat(formData.totalAmount || 0) > 0 ? remaining.toString() : ''
    };

    if (deal) {
      const result = updateDeal(deal.id, finalData);
      if (result.success) {
        toast({
          title: "Deal updated!",
          description: "Your deal has been successfully updated.",
        });
        onClose();
      }
    } else {
      const result = addDeal(finalData);
      if (result.success) {
        const reward = formData.dealType === 'main' ? 2000 : 1000;
        toast({
          title: "Deal submitted successfully!",
          description: `Case ID: ${result.caseId} | Reward: ${reward} PKR for approved deal.`,
        });
        onClose();
      }
    }
  };

  const handleAmountChange = (field, value) => {
    setFormData(prev => {
      const updated = { ...prev, [field]: value };
      let totalPaid = 0;
      Object.values(updated.installments).forEach(inst => {
        if (inst.paid && inst.amount) {
          totalPaid += parseFloat(inst.amount);
        }
      });
      updated.paidAmount = totalPaid > 0 ? totalPaid.toString() : '';
      const remaining = (parseFloat(updated.totalAmount || 0) - totalPaid);
      updated.remainingPayment = remaining > 0 || parseFloat(updated.totalAmount || 0) > 0 ? remaining.toString() : '';
      return updated;
    });
  };

  const handleInstallmentChange = (installmentKey, field, value) => {
    setFormData(prev => {
      const newInstallments = {
        ...prev.installments,
        [installmentKey]: {
          ...prev.installments[installmentKey],
          [field]: field === 'paid' ? value : value
        }
      };
      let totalPaid = 0;
      Object.values(newInstallments).forEach(inst => {
        if (inst.paid && inst.amount) {
          totalPaid += parseFloat(inst.amount);
        }
      });
      const remaining = (parseFloat(prev.totalAmount || 0) - totalPaid);
      return {
        ...prev,
        installments: newInstallments,
        paidAmount: totalPaid > 0 ? totalPaid.toString() : '',
        remainingPayment: remaining > 0 || parseFloat(prev.totalAmount || 0) > 0 ? remaining.toString() : ''
      };
    });
  };
  const handleInputChange = (eOrValue, index, field) => {
    const value = typeof eOrValue === 'string' ? eOrValue : eOrValue.target.value;

    setFormData(prev => ({
      ...prev,
      userDetails: prev.userDetails.map((user, i) =>
        i === index ? { ...user, [field]: value } : user
      )
    }));
  };
  const handleAddNewClient = () => {
    setFormData(prev => ({
      ...prev,
      userDetails: [
        ...prev.userDetails,
        {
          firstName: '',
          lastName: '',
          passportNumber: '',
          nationality: '',
          phoneNumber: '',
        }
      ]
    }));
  }
  const handleRemoveClient = (index) => {
    let copyArray = [...formData.userDetails]
    copyArray.splice(index, 1)
    setFormData(prev => ({
      ...prev,
      userDetails: copyArray
    }))
  }

  const [fullscreenImage, setFullscreenImage] = useState(null);

  const handleFileChange = (installmentKey, e) => {
    const file = e.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setFormData(prev => ({
        ...prev,
        installments: {
          ...prev.installments,
          [installmentKey]: {
            ...prev.installments[installmentKey],
            img: imageUrl
          }
        }
      }));
    }
  };

  const removeImage = (installmentKey, e) => {
    e.stopPropagation();

    setFormData(prev => ({
      ...prev,
      installments: {
        ...prev.installments,
        [installmentKey]: {
          ...prev.installments[installmentKey],
          img: ''
        }
      }
    }));

    // Clear the file input
    const fileInput = document.getElementById(`fileInput-${installmentKey}`);
    if (fileInput) {
      fileInput.value = '';
    }
  };

  const openFullscreen = (imageUrl, e) => {
    e.stopPropagation();
    setFullscreenImage(imageUrl);
  };

  const closeFullscreen = (e) => {
    e?.stopPropagation();
    setFullscreenImage(null);
  };


  const selectedCurrency = currencies.find(c => c.value === formData.currency);
  console.log('formData ', formData)
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-effect border-purple-500/20 text-white max-w-3xl max-h-[90vh] overflow-y-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <DialogHeader>
            <DialogTitle className="text-white text-xl flex items-center">
              <FileText className="mr-2 h-5 w-5 text-purple-400" />
              {deal ? 'Edit Deal' : 'Add New Deal'}
            </DialogTitle>
            <DialogDescription className="text-purple-300">
              {deal ? 'Update deal information' : 'Submit a new visa application deal'}
            </DialogDescription>
          </DialogHeader>
          {formData.dealType == 'family' &&
            <DialogTitle className="text-white text-xl flex items-center">
              <User className="mr-2 h-5 w-5 text-purple-400" />
              Total Members: {formData?.userDetails?.length}
            </DialogTitle>
          }
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="text-white">Deal Type & Reward</Label>
              <Select value={formData.dealType} onValueChange={(value) => setFormData(prev => ({ ...prev, dealType: value }))}>
                <SelectTrigger className="glass-effect border-purple-500/20 text-white">
                  <SelectValue placeholder="Select deal type" />
                </SelectTrigger>
                <SelectContent className="glass-effect border-purple-500/20">
                  {dealTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="paymentMethod" className="text-white">Overall Payment Method</Label>
              <Select value={formData.paymentMethod} onValueChange={(value) => setFormData(prev => ({ ...prev, paymentMethod: value }))}>
                <SelectTrigger className="glass-effect border-purple-500/20 text-white">
                  <SelectValue placeholder="Select payment method" />
                </SelectTrigger>
                <SelectContent className="glass-effect border-purple-500/20">
                  {paymentMethods.map(method => (
                    <SelectItem key={method.value} value={method.value}>
                      {method.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            {formData?.userDetails?.map((userDetails, index) => {
              return (
                <>
                  <h3 className={`text-lg font-semibold text-white flex items-center mb-3 ${index > 0 ? 'mt-8' : ''}`}>
                    <User className="mr-2 h-5 w-5 text-purple-400" />
                    Client Information
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <InputGroup label="First Name" id="firstName" value={userDetails.firstName} onChange={(e) => handleInputChange(e, index, 'firstName')} placeholder="Client's first name" required />
                    <InputGroup label="Last Name" id="lastName" value={userDetails.lastName} onChange={(e) => handleInputChange(e, index, 'lastName')} placeholder="Client's last name" required />
                    <InputGroup label="Passport Number" id="passportNumber" value={userDetails.passportNumber} onChange={(e) => handleInputChange(e, index, 'passportNumber')} placeholder="Passport number" required />
                    <InputGroup label="Phone Number" id="phoneNumber" value={userDetails.phoneNumber} onChange={(e) => handleInputChange(e, index, 'phoneNumber')} placeholder="+92 300 1234567" required />
                    <SelectGroupWithSearch label="Nationality" id="nationality" value={userDetails.nationality} onValueChange={(value) => handleInputChange(value, index, 'nationality')} placeholder="Select nationality" options={countries.map(c => ({ value: c.name, label: c.name }))} />
                    <div className={`grid grid-cols-1 mt-8 md:${index > 0 ? 'grid-cols-2' : 'grid-cols-1'} gap-4`}>

                      {formData.dealType == 'family' && <Button
                        onClick={() => { handleAddNewClient() }}
                        className=" hover:scale-105 transition-transform w-full sm:w-auto flex-shrink-0"
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Add New Member
                      </Button>
                      }
                      {index > 0 && <Button
                        onClick={() => { handleRemoveClient(index) }}
                        className=" hover:scale-105 transition-transform w-full sm:w-auto flex-shrink-0"
                      >
                        <Minus className="mr-2 h-4 w-4" />
                        Remove Member
                      </Button>
                      }
                    </div>
                  </div>

                </>
              )
            })}
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white flex items-center mb-3">
              <MapPin className="mr-2 h-5 w-5 text-purple-400" />
              Application Details
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <SelectGroupWithSearch label="Apply From" id="applyFrom" value={formData.applyFrom} onValueChange={(value) => setFormData(prev => ({ ...prev, applyFrom: value }))} placeholder="Select country" options={countries.map(c => ({ value: c.name, label: c.name }))} />
              <SelectGroupWithSearch label="Apply For (Destination)" id="applyFor" value={formData.applyFor} onValueChange={(value) => setFormData(prev => ({ ...prev, applyFor: value }))} placeholder="Select destination" options={countries.map(c => ({ value: c.name, label: c.name }))} />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white flex items-center mb-3">
              <CreditCard className="mr-2 h-5 w-5 text-purple-400" />
              Financials
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <SelectGroupComp label="Currency" id="currency" value={formData.currency} onValueChange={(value) => setFormData(prev => ({ ...prev, currency: value }))} placeholder="Select currency" options={currencies} />
              <InputGroup label={`Total Amount (${selectedCurrency?.symbol})`} id="totalAmount" type="number" value={formData.totalAmount} onChange={(e) => handleAmountChange('totalAmount', e.target.value)} placeholder="" required />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <InputGroup label={`Paid Amount (${selectedCurrency?.symbol})`} id="paidAmount" type="number" value={formData.paidAmount} readOnly className="bg-purple-500/10" placeholder="" />
              <InputGroup label={`Remaining (${selectedCurrency?.symbol})`} id="remainingPayment" type="number" value={formData.remainingPayment} readOnly className="bg-purple-500/10" placeholder="" />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white flex items-center mb-3">
              <Wallet className="mr-2 h-5 w-5 text-purple-400" />
              Installments (Optional)
            </h3>
            {Object.entries(formData.installments).map(([key, inst], index) => (
              <div key={key} className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 p-3 border border-purple-500/20 rounded-lg">
                <InputGroup
                  label={`${index + 1}${index === 0 ? 'st' : index === 1 ? 'nd' : index === 2 ? 'rd' : 'th'} Installment Amount`}
                  id={`${key}Amount`}
                  type="number"
                  value={inst.amount || ''}
                  onChange={(e) => handleInstallmentChange(key, 'amount', e.target.value)}
                  placeholder=""
                />
                <SelectGroupComp
                  label="Payment Method"
                  id={`${key}PaymentMethod`}
                  value={inst.paymentMethod}
                  onValueChange={(value) => handleInstallmentChange(key, 'paymentMethod', value)}
                  placeholder="Method"
                  options={paymentMethods}
                />
                <div className="flex items-end gap-2">
                  <div className="relative">
                    {/* Hidden file input for this installment */}
                    <input
                      type="file"
                      accept="image/*"
                      id={`fileInput-${key}`}
                      onChange={(e) => handleFileChange(key, e)}
                      className="hidden"
                    />

                    {/* Upload Button */}
                    {!inst.img && (
                      <button
                        onClick={() => document.getElementById(`fileInput-${key}`).click()}
                        className="w-10 h-10 flex items-center justify-center border border-dashed border-gray-400 rounded hover:border-gray-600 transition-colors"
                        title="Upload image"
                      >
                        <Plus className="text-gray-500" size={20} />
                      </button>
                    )}

                    {/* Image Preview with Actions */}
                    {inst.img && (
                      <div className="relative w-16 h-16 group rounded overflow-hidden border cursor-pointer">
                        {/* Preview Image */}
                        <img
                          src={inst.img}
                          alt={`Installment ${index + 1} Proof`}
                          className="w-full h-full object-cover"
                          onClick={(e) => openFullscreen(inst.img, e)}
                        />

                        {/* Overlay for Maximize Icon */}
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 flex items-center justify-center transition-all">
                          <Maximize2 size={16} className="text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>

                        {/* Remove Image Icon */}
                        <button
                          onClick={(e) => removeImage(key, e)}
                          className="absolute -top-2 -right-2 bg-red-500 text-white p-0.5 rounded-full hover:bg-red-600 transition-all z-10"
                          title="Remove"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    )}
                  </div>

                  <Button
                    type="button"
                    variant={inst.paid ? "secondary" : "outline"}
                    onClick={() => handleInstallmentChange(key, 'paid', !inst.paid)}
                    className="w-full"
                  >
                    {inst.paid ? 'Paid' : 'Mark as Paid'}
                  </Button>
                </div>
              </div>
            ))}

            {/* Fullscreen View (single instance for all installments) */}
            {fullscreenImage && (
              <div
                className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center"
                onClick={closeFullscreen}
              >
                <div className="relative max-w-full max-h-full">
                  <img
                    src={fullscreenImage}
                    alt="Fullscreen Proof"
                    className="max-w-full max-h-[90vh] object-contain"
                  />
                  <button
                    onClick={closeFullscreen}
                    className="absolute -top-10 right-0 bg-red-500 text-white p-2 rounded-full hover:bg-red-600"
                  >
                    <X size={20} />
                  </button>
                </div>
              </div>
            )}
          </div>
          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="border-purple-500/20 text-white hover:bg-purple-500/10">Cancel</Button>
            <Button type="submit" className="bolt-gradient hover:scale-105 transition-transform">{deal ? 'Update' : 'Submit'} Deal</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

const InputGroup = ({ label, id, ...props }) => (
  <div className="space-y-2">
    <Label htmlFor={id} className="text-white">{label}</Label>
    <Input id={id} className="glass-effect border-purple-500/20 text-white placeholder:text-purple-300" {...props} />
  </div>
);

const SelectGroupComp = ({ label, id, value, onValueChange, placeholder, options }) => (
  <div className="space-y-2">
    <Label htmlFor={id} className="text-white">{label}</Label>
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger id={id} className="glass-effect border-purple-500/20 text-white">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent className="glass-effect border-purple-500/20 max-h-60 ">
        <SelectGroup>
          {options.map(option => (
            <SelectItem key={option.value} value={option.value}>
              {option.label}
            </SelectItem>
          ))}
        </SelectGroup>
      </SelectContent>
    </Select>
  </div>
);

const SelectGroupWithSearch = ({ label, id, value, onValueChange, placeholder, options }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredOptions = useMemo(() => {
    if (!searchTerm) return options;
    return options.filter(option =>
      option.label.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [options, searchTerm]);

  return (
    <div className="space-y-2">
      <Label htmlFor={id} className="text-white">{label}</Label>
      <Select value={value} onValueChange={onValueChange}>
        <SelectTrigger id={id} className="glass-effect border-purple-500/20 text-white">
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent className="glass-effect border-purple-500/20 max-h-72">
          <div className="p-2 sticky top-0 bg-[hsl(var(--popover))] z-10">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-purple-300" />
              <Input
                type="text"
                placeholder="Search..."
                className="glass-effect border-purple-500/20 text-white placeholder:text-purple-300 pl-8 h-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onClick={(e) => e.stopPropagation()}
              />
            </div>
          </div>
          <SelectGroup className="overflow-y-auto max-h-[calc(18rem-3rem)]">
            {filteredOptions.length > 0 ? (
              filteredOptions.map(option => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))
            ) : (
              <div className="p-2 text-center text-purple-300 text-sm">No countries found.</div>
            )}
          </SelectGroup>
        </SelectContent>
      </Select>
    </div>
  );
};


export default DealForm;    